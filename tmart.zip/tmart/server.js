

const express = require('express')
const mongoose = require('mongoose')
const app = express()
app.listen(5500, function (err) {
     if (err)
          console.log(err)
     else {
          console.log('server started at port 5500')
     }
})
const MongoClient = require('mongodb').MongoClient
mongoose.connect('mongodb+srv://yeruult:91583303@cluster0.dapql.mongodb.net/yeruultdb?retryWrites=true&w=majority')

app.use('tmart/css', express.static(__dirname + 'tmart/css'))
app.use('tmart/images', express.static(__dirname + 'tmart/images'))
app.use('tmart/js', express.static(__dirname + 'tmart/js'))
app.use('tmart/views', express.static(__dirname + 'tmart/views'))

app.set('/views', './views')
app.set('view engine', 'ejs')

app.get('/', function (req, res) {
     res.sendFile(__dirname + '/')
})

app.get('/views', function (req, res) {
     res.sendFile(__dirname + '/views/index.html')
})

app.get('/views', (req, res) => {
     res.sendFile(__dirname + '/views/contact.html')
})

